# Importing a library into your code

# os is a library, system is the function, write command in the .system() to show an output
import os

print(os.system("df -h")) # Size of Disks/Drives attached to system 
print(os.system("free -h")) # RAM in system
print(os.system("uptime")) # Uptime and load average of system