#Converting the input to lower case by build-in function .lower()
day_of_week = print(input("Enter a day in UPPER Case: ").lower())
# OR
month_of_year = input("Enter a year UPPER Case: ").lower()
print(month_of_year)


#Converting the input to upper case by build-in function .upper()
school_name = print(input("Enter a school name in lower case: ").upper())
# OR
collage_name = input("Enter a Collage name lower case: ").upper()
print(collage_name)